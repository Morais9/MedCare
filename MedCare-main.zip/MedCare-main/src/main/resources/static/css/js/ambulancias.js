
document.addEventListener("DOMContentLoaded", () => {

    const area = document.getElementById(
        "rastreamentoAmbulancias"
    );

    if (!area) return;

    const API = "/api/admin/ambulancias";

    const mensagem = document.getElementById(
        "mensagemAmbulancia"
    );

    const conexao = document.getElementById(
        "statusConexao"
    );

    const lista = document.getElementById(
        "listaAmbulancias"
    );

    const historico = document.getElementById(
        "historicoAmbulancia"
    );

    const tituloSelecionada = document.getElementById(
        "ambulanciaSelecionada"
    );

    const seletorRota = document.getElementById(
        "rotaAmbulancia"
    );

    const csrf = document.querySelector(
        'meta[name="_csrf"]'
    )?.content;

    const csrfHeader = document.querySelector(
        'meta[name="_csrf_header"]'
    )?.content || "X-CSRF-TOKEN";


    // MAPA LEAFLET
    const mapa = L.map("mapaAmbulancias")
        .setView([-22.90556, -47.06083], 13);

    L.tileLayer(
        "https://tile.openstreetmap.org/{z}/{x}/{y}.png",
        {
            maxZoom: 19,
            attribution:
                '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
        }
    ).addTo(mapa);


    const ambulancias = new Map();
    const marcadores = new Map();

    let selecionadaId = null;
    let linhaPlanejada = null;
    let linhaPercorrida = null;


    // MENSAGENS
    function avisar(texto, erro = false) {
        mensagem.textContent = texto;
        mensagem.classList.toggle(
            "erro", erro
        );
    }


    // REQUISIÇÕES REST
    async function requisitar(
        url,
        metodo = "GET",
        corpo = undefined
    ) {

        const headers = {
            "Accept": "application/json"
        };

        if (metodo !== "GET") {
            headers[csrfHeader] = csrf;
        }

        if (corpo !== undefined) {
            headers["Content-Type"] = "application/json";
        }

        const resposta = await fetch(url, {
            method: metodo,
            credentials: "same-origin",
            headers,
            body: corpo === undefined
                ? undefined
                : JSON.stringify(corpo)
        });

        if (!resposta.ok) {
            const dados = await resposta.json()
                .catch(() => ({}));

            throw new Error(
                dados.erro ||
                "Operação não realizada: HTTP " +
                resposta.status
            );
        }

        return resposta.json();
    }


    // CORES POR STATUS
    function corStatus(status) {

        switch (status) {
            case "EM_ANDAMENTO":
                return "#22a86a";

            case "PAUSADA":
                return "#d49d35";

            case "FINALIZADA":
                return "#627c91";

            default:
                return "#397a63";
        }
    }


    // ATUALIZAR OU CRIAR MARCADOR
    function atualizarMarcador(ambulancia) {

        const posicao = [
            ambulancia.latitude,
            ambulancia.longitude
        ];

        let marcador = marcadores.get(ambulancia.id);

        if (!marcador) {

            marcador = L.circleMarker(posicao, {
                radius: 9,
                color: "#ffffff",
                weight: 2,
                fillColor: corStatus(ambulancia.status),
                fillOpacity: 1
            }).addTo(mapa);

            marcador.bindTooltip(
                ambulancia.codigo
            );

            marcador.on("click", () => {
                selecionarAmbulancia(ambulancia.id);
            });

            marcadores.set(ambulancia.id, marcador);

        } else {

            marcador.setLatLng(posicao);

            marcador.setStyle({
                fillColor: corStatus(ambulancia.status)
            });
        }
    }


    // CRIAR BOTÕES COM SEGURANÇA
    function botao(texto, acao) {

        const elemento =
            document.createElement("button");

        elemento.type = "button";
        elemento.textContent = texto;
        elemento.className = "ambulancia-botao";

        elemento.addEventListener("click", acao);

        return elemento;
    }


    // EXECUTAR UMA AÇÃO
    async function executarAcao(endereco, corpo) {

        try {
            await requisitar(
                endereco,
                "POST",
                corpo
            );

            avisar("Operação realizada.");

            await carregarAmbulancias();

        } catch (erro) {
            avisar(erro.message, true);
        }
    }


    // MOSTRAR AMBULÂNCIAS NA LISTA
    function renderizarLista() {

        lista.replaceChildren();

        if (ambulancias.size === 0) {
            lista.textContent =
                "Nenhuma ambulância cadastrada.";
            return;
        }

        const ordenadas = [...ambulancias.values()]
            .sort((a, b) =>
                a.codigo.localeCompare(b.codigo)
            );

        ordenadas.forEach(ambulancia => {

            const linha = document.createElement("div");
            linha.className = "ambulancia-item";

            if (ambulancia.id === selecionadaId) {
                linha.classList.add("selecionada");
            }

            const identificacao =
                document.createElement("div");

            identificacao.className =
                "ambulancia-identificacao";

            const nome = document.createElement("strong");

            nome.textContent =
                ambulancia.codigo + " — " +
                ambulancia.nome;

            const status = document.createElement("span");

            status.textContent =
                ambulancia.status.replaceAll("_", " ");

            status.style.color =
                corStatus(ambulancia.status);

            identificacao.append(nome, status);

            const acoes = document.createElement("div");
            acoes.className = "ambulancia-acoes";

            acoes.append(
                botao("Ver", () => {
                    selecionarAmbulancia(ambulancia.id);
                })
            );

            if (
                ambulancia.status === "DISPONIVEL" ||
                ambulancia.status === "FINALIZADA"
            ) {

                acoes.append(
                    botao("Iniciar", () =>
                        executarAcao(
                            API + "/" + ambulancia.id +
                            "/iniciar",
                            { trajeto: seletorRota.value }
                        )
                    )
                );
            }

            if (ambulancia.status === "EM_ANDAMENTO") {

                acoes.append(
                    botao("Pausar", () =>
                        executarAcao(
                            API + "/simulacoes/" +
                            ambulancia.simulacaoId +
                            "/pausar"
                        )
                    )
                );
            }

            if (ambulancia.status === "PAUSADA") {

                acoes.append(
                    botao("Retomar", () =>
                        executarAcao(
                            API + "/simulacoes/" +
                            ambulancia.simulacaoId +
                            "/retomar"
                        )
                    )
                );
            }

            if (
                ambulancia.status === "EM_ANDAMENTO" ||
                ambulancia.status === "PAUSADA"
            ) {

                acoes.append(
                    botao("Finalizar", () =>
                        executarAcao(
                            API + "/simulacoes/" +
                            ambulancia.simulacaoId +
                            "/finalizar"
                        )
                    )
                );
            }

            linha.append(identificacao, acoes);

            lista.appendChild(linha);
        });
    }


    // DESENHAR HISTÓRICO E ROTA
    async function atualizarTrajetos() {

        if (selecionadaId === null) return;

        const id = selecionadaId;
        const ambulancia = ambulancias.get(id);

        if (!ambulancia) return;

        const tipoRota =
            ambulancia.trajeto || seletorRota.value;

        const [rota, pontos] = await Promise.all([
            requisitar(API + "/rotas/" + tipoRota),
            requisitar(API + "/" + id + "/historico")
        ]);

        // Evitar desenho atrasado de outra seleção.
        if (selecionadaId !== id) return;

        if (linhaPlanejada) {
            mapa.removeLayer(linhaPlanejada);
        }

        if (linhaPercorrida) {
            mapa.removeLayer(linhaPercorrida);
        }

        linhaPlanejada = L.polyline(
            rota.map(p => [
                p.latitude,
                p.longitude
            ]),
            {
                color: "#6d8291",
                weight: 3,
                opacity: 0.6,
                dashArray: "8 6"
            }
        ).addTo(mapa);

        linhaPercorrida = L.polyline(
            pontos.map(p => [
                p.latitude,
                p.longitude
            ]),
            {
                color: "#2aaa6a",
                weight: 5
            }
        ).addTo(mapa);

        tituloSelecionada.textContent =
            ambulancia.codigo + " — " +
            ambulancia.status.replaceAll("_", " ");

        historico.replaceChildren();

        const ultimos = pontos.slice(-8).reverse();

        if (ultimos.length === 0) {
            historico.textContent =
                "Ainda não existem posições registradas.";
        }

        ultimos.forEach(p => {

            const item = document.createElement("div");

            item.textContent =
                "Ponto " + p.indice +
                " | " +
                p.latitude.toFixed(5) +
                ", " +
                p.longitude.toFixed(5);

            historico.appendChild(item);
        });
    }


    // SELECIONAR UMA AMBULÂNCIA
    async function selecionarAmbulancia(id) {

        selecionadaId = id;

        const ambulancia = ambulancias.get(id);

        if (!ambulancia) return;

        mapa.setView(
            [ambulancia.latitude, ambulancia.longitude],
            14
        );

        renderizarLista();

        try {
            await atualizarTrajetos();
        } catch (erro) {
            avisar(erro.message, true);
        }
    }


    // CARREGAR DADOS EXISTENTES DO MYSQL
    async function carregarAmbulancias() {

        try {
            const dados = await requisitar(API);

            ambulancias.clear();

            dados.forEach(item => {
                ambulancias.set(item.id, item);
                atualizarMarcador(item);
            });

            renderizarLista();

            if (selecionadaId !== null &&
                    ambulancias.has(selecionadaId)) {

                await atualizarTrajetos();

            } else if (dados.length > 0) {

                await selecionarAmbulancia(dados[0].id);
            }

        } catch (erro) {
            avisar(erro.message, true);
        }
    }


    // CADASTRAR NOVA AMBULÂNCIA
    document.getElementById(
        "formCadastroAmbulancia"
    ).addEventListener("submit", async evento => {

        evento.preventDefault();

        const codigo = document.getElementById(
            "codigoAmbulancia"
        ).value;

        const nome = document.getElementById(
            "nomeAmbulancia"
        ).value;

        try {

            await requisitar(API, "POST", {
                codigo,
                nome
            });

            evento.target.reset();

            avisar("Ambulância cadastrada com sucesso.");

            await carregarAmbulancias();

        } catch (erro) {
            avisar(erro.message, true);
        }
    });


    // VISUALIZAR OUTRO TRAJETO PLANEJADO
    seletorRota.addEventListener("change", () => {

        const selecionada = ambulancias.get(selecionadaId);

        if (!selecionada || !selecionada.trajeto) {
            atualizarTrajetos().catch(erro =>
                avisar(erro.message, true)
            );
        }
    });


    // WEBSOCKET + STOMP
    const protocolo =
        location.protocol === "https:" ? "wss:" : "ws:";

    const enderecoWebSocket =
        protocolo + "//" +
        location.host +
        "/ws/ambulancias";

    const cliente = new StompJs.Client({

        brokerURL: enderecoWebSocket,

        reconnectDelay: 5000,

        onConnect: () => {

            conexao.textContent = "Conectado";

            cliente.subscribe(
                "/topic/admin/ambulancias",
                mensagemRecebida => {

                    const item = JSON.parse(
                        mensagemRecebida.body
                    );

                    ambulancias.set(item.id, item);

                    atualizarMarcador(item);
                    renderizarLista();

                    if (item.id === selecionadaId) {

                        atualizarTrajetos().catch(erro =>
                            avisar(erro.message, true)
                        );
                    }
                }
            );

            // Sincronizar dados após uma reconexão.
            carregarAmbulancias();
        },

        onWebSocketClose: () => {
            conexao.textContent = "Reconectando...";
        },

        onStompError: quadro => {
            conexao.textContent = "Erro de conexão";
            console.error(quadro);
        }

    });

    cliente.activate();

    // Exibir dados persistidos mesmo antes do WebSocket.
    carregarAmbulancias();

    // Ajustar tamanho após carregamento da página.
    setTimeout(() => mapa.invalidateSize(), 200);

});
