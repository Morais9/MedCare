package com.medcare.config;

import org.springframework.context.annotation.Configuration;

import org.springframework.messaging.Message;
import org.springframework.messaging.MessageChannel;
import org.springframework.messaging.simp.config.ChannelRegistration;
import org.springframework.messaging.simp.config.MessageBrokerRegistry;

import org.springframework.messaging.support.ChannelInterceptor;
import org.springframework.messaging.simp.stomp.StompCommand;
import org.springframework.messaging.simp.stomp.StompHeaderAccessor;

import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.core.Authentication;

import org.springframework.web.socket.config.annotation.*;

@Configuration
@EnableWebSocketMessageBroker
public class AmbulanciaWebSocketConfig
        implements WebSocketMessageBrokerConfigurer {

    @Override
    public void registerStompEndpoints(
            StompEndpointRegistry registry) {

        // Endpoint WebSocket nativo.
        // Mantemos a política padrão de mesma origem.
        registry.addEndpoint("/ws/ambulancias");
    }

    @Override
    public void configureMessageBroker(
            MessageBrokerRegistry registry) {

        registry.enableSimpleBroker("/topic");

        registry.setApplicationDestinationPrefixes("/app");
    }

    @Override
    public void configureClientInboundChannel(
            ChannelRegistration registration) {

        registration.interceptors(new ChannelInterceptor() {

            @Override
            public Message<?> preSend(
                    Message<?> message,
                    MessageChannel channel) {

                StompHeaderAccessor accessor =
                        StompHeaderAccessor.wrap(message);

                StompCommand comando = accessor.getCommand();

                if (comando == null) {
                    return message;
                }

                if (comando == StompCommand.CONNECT ||
                        comando == StompCommand.SUBSCRIBE ||
                        comando == StompCommand.SEND) {

                    Authentication autenticacao =
                            accessor.getUser() instanceof Authentication a
                                    ? a
                                    : null;

                    boolean autorizado =
                            autenticacao != null &&
                                    autenticacao.isAuthenticated() &&
                                    autenticacao.getAuthorities()
                                            .stream()
                                            .anyMatch(permissao ->
                                                    permissao.getAuthority()
                                                            .equals("ROLE_ADMIN")
                                            );

                    if (!autorizado) {
                        throw new AccessDeniedException(
                                "Acesso WebSocket administrativo negado."
                        );
                    }
                }

                // O navegador não envia posições.
                // Somente o backend publica atualizações.
                if (comando == StompCommand.SEND) {
                    throw new AccessDeniedException(
                            "Envio STOMP não permitido."
                    );
                }

                if (comando == StompCommand.SUBSCRIBE) {

                    String destino = accessor.getDestination();

                    if (!"/topic/admin/ambulancias".equals(destino)) {
                        throw new AccessDeniedException(
                                "Inscrição STOMP não autorizada."
                        );
                    }
                }

                return message;
            }
        });
    }
}
