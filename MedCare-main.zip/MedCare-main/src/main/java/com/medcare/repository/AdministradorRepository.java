package com.medcare.repository;

import com.medcare.model.Administrador;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface AdministradorRepository
        extends JpaRepository<Administrador, Long> {

    boolean existsByUsuario_Id(Long usuarioId);

    @Query("SELECT a.usuario.id FROM Administrador a")
    List<Long> listarIdsDeAdministradores();
}
