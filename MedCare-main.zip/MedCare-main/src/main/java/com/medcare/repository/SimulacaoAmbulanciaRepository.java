package com.medcare.repository;

import com.medcare.model.*;
import jakarta.persistence.LockModeType;
import org.springframework.data.jpa.repository.*;
import org.springframework.data.repository.query.Param;

import java.util.Collection;
import java.util.List;
import java.util.Optional;

public interface SimulacaoAmbulanciaRepository
        extends JpaRepository<SimulacaoAmbulancia, Long> {

    Optional<SimulacaoAmbulancia>
    findFirstByAmbulanciaIdOrderByIdDesc(
            Long ambulanciaId
    );

    boolean existsByAmbulanciaIdAndStatusIn(
            Long ambulanciaId,
            Collection<StatusSimulacao> status
    );

    List<SimulacaoAmbulancia> findByStatus(
            StatusSimulacao status
    );

    @Lock(LockModeType.PESSIMISTIC_WRITE)
    @Query("SELECT s FROM SimulacaoAmbulancia s " +
            "WHERE s.id = :id")
    Optional<SimulacaoAmbulancia> bloquearPorId(
            @Param("id") Long id
    );
}
