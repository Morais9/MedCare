package com.medcare.repository;

import com.medcare.model.LocalizacaoAmbulancia;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface LocalizacaoAmbulanciaRepository
        extends JpaRepository<LocalizacaoAmbulancia, Long> {

    List<LocalizacaoAmbulancia>
    findBySimulacaoIdOrderByIndiceAsc(
            Long simulacaoId
    );

    Optional<LocalizacaoAmbulancia>
    findFirstBySimulacaoIdOrderByIndiceDesc(
            Long simulacaoId
    );
}
