package com.medcare.repository;

import java.util.List;
import java.util.Optional;
import com.medcare.model.Categoria;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CategoriaRepository
        extends JpaRepository<Categoria, Long> {

    boolean existsByNomeIgnoreCase(String nome);

    boolean existsByNomeIgnoreCaseAndIdNot(
            String nome,
            Long id
    );

    List<Categoria> findByAtivoTrueOrderByNomeAsc();

    Optional<Categoria> findByNomeIgnoreCaseAndAtivoTrue(
            String nome
    );
}
