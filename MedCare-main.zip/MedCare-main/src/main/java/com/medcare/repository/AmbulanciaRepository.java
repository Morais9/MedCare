package com.medcare.repository;

import com.medcare.model.Ambulancia;
import jakarta.persistence.LockModeType;
import org.springframework.data.jpa.repository.*;
import org.springframework.data.repository.query.Param;

import java.util.Optional;

public interface AmbulanciaRepository
        extends JpaRepository<Ambulancia, Long> {

    boolean existsByCodigoIgnoreCase(String codigo);

    @Lock(LockModeType.PESSIMISTIC_WRITE)
    @Query("SELECT a FROM Ambulancia a WHERE a.id = :id")
    Optional<Ambulancia> bloquearPorId(
            @Param("id") Long id
    );
}
