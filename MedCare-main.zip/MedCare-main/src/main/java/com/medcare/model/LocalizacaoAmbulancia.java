package com.medcare.model;

import jakarta.persistence.*;
import java.time.Instant;

@Entity
@Table(
        name = "localizacoes_ambulancias",
        uniqueConstraints = @UniqueConstraint(
                columnNames = {"simulacao_id", "indice"}
        )
)
public class LocalizacaoAmbulancia {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "simulacao_id", nullable = false)
    private SimulacaoAmbulancia simulacao;

    @Column(nullable = false)
    private int indice;

    @Column(nullable = false)
    private double latitude;

    @Column(nullable = false)
    private double longitude;

    @Column(name = "registrada_em", nullable = false)
    private Instant registradaEm;

    public Long getId() { return id; }

    public SimulacaoAmbulancia getSimulacao() {
        return simulacao;
    }
    public void setSimulacao(
            SimulacaoAmbulancia simulacao) {
        this.simulacao = simulacao;
    }

    public int getIndice() { return indice; }
    public void setIndice(int indice) {
        this.indice = indice;
    }

    public double getLatitude() { return latitude; }
    public void setLatitude(double latitude) {
        this.latitude = latitude;
    }

    public double getLongitude() { return longitude; }
    public void setLongitude(double longitude) {
        this.longitude = longitude;
    }

    public Instant getRegistradaEm() {
        return registradaEm;
    }
    public void setRegistradaEm(Instant registradaEm) {
        this.registradaEm = registradaEm;
    }
}
