package com.medcare.model;

public enum StatusSimulacao {
    EM_ANDAMENTO,
    PAUSADA,
    FINALIZADA
}