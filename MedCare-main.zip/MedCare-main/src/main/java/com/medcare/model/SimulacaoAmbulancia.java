package com.medcare.model;

import jakarta.persistence.*;
import java.time.Instant;

@Entity
@Table(name = "simulacoes_ambulancias")
public class SimulacaoAmbulancia {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "ambulancia_id", nullable = false)
    private Ambulancia ambulancia;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 30)
    private TipoTrajeto trajeto;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 30)
    private StatusSimulacao status;

    @Column(name = "indice_atual", nullable = false)
    private int indiceAtual;

    @Column(name = "iniciada_em", nullable = false)
    private Instant iniciadaEm;

    @Column(name = "finalizada_em")
    private Instant finalizadaEm;

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public Ambulancia getAmbulancia() {
        return ambulancia;
    }
    public void setAmbulancia(Ambulancia ambulancia) {
        this.ambulancia = ambulancia;
    }

    public TipoTrajeto getTrajeto() { return trajeto; }
    public void setTrajeto(TipoTrajeto trajeto) {
        this.trajeto = trajeto;
    }

    public StatusSimulacao getStatus() { return status; }
    public void setStatus(StatusSimulacao status) {
        this.status = status;
    }

    public int getIndiceAtual() { return indiceAtual; }
    public void setIndiceAtual(int indiceAtual) {
        this.indiceAtual = indiceAtual;
    }

    public Instant getIniciadaEm() { return iniciadaEm; }
    public void setIniciadaEm(Instant iniciadaEm) {
        this.iniciadaEm = iniciadaEm;
    }

    public Instant getFinalizadaEm() {
        return finalizadaEm;
    }
    public void setFinalizadaEm(Instant finalizadaEm) {
        this.finalizadaEm = finalizadaEm;
    }
}
