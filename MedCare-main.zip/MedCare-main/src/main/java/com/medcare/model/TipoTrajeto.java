package com.medcare.model;

public enum TipoTrajeto {
    CENTRO_CAMBUI,
    CENTRO_TAQUARAL
}