package com.medcare.service;

import com.medcare.dto.AdminUsuarioForm;
import com.medcare.model.Usuario;

import com.medcare.repository.UsuarioRepository;
import com.medcare.repository.AgendamentoRepository;
import com.medcare.repository.AdministradorRepository;

import com.medcare.repository.HistoricoExameRepository;
import com.medcare.repository.ResultadoExameRepository;
import com.medcare.repository.AnexoExameRepository;
import org.springframework.data.domain.Sort;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.text.Normalizer;
import java.util.Locale;
import java.util.List;
import java.util.Set;
import java.util.regex.Pattern;

@Service
@Transactional(readOnly = true)
public class AdministracaoService {

    private static final Set<String> CARGOS = Set.of(
            "Recepcionista",
            "Medico",
            "Enfermeira",
            "Radiologista",
            "Outro profissional"
    );

    private static final Set<String> CARGOS_ATENDIMENTO =
            Set.of(
                    "Medico",
                    "Enfermeira",
                    "Radiologista",
                    "Outro profissional"
            );

    private static final Pattern EMAIL = Pattern.compile(
            "^[^\\s@]+@[^\\s@]+\\.[^\\s@]+$"
    );

    private final UsuarioRepository usuarioRepository;
    private final AgendamentoRepository agendamentoRepository;
    private final AdministradorRepository administradorRepository;
    private final UsuarioService usuarioService;
    private final PasswordEncoder passwordEncoder;

    private final HistoricoExameRepository historicoExameRepository;
    private final ResultadoExameRepository resultadoExameRepository;
    private final AnexoExameRepository anexoExameRepository;

    public AdministracaoService(
            UsuarioRepository usuarioRepository,
            AgendamentoRepository agendamentoRepository,
            AdministradorRepository administradorRepository,
            UsuarioService usuarioService,
            PasswordEncoder passwordEncoder,HistoricoExameRepository historicoExameRepository,
            ResultadoExameRepository resultadoExameRepository,
            AnexoExameRepository anexoExameRepository) {

        this.usuarioRepository = usuarioRepository;
        this.agendamentoRepository = agendamentoRepository;
        this.administradorRepository = administradorRepository;
        this.usuarioService = usuarioService;
        this.passwordEncoder = passwordEncoder;
        this.historicoExameRepository = historicoExameRepository;
        this.resultadoExameRepository = resultadoExameRepository;
        this.anexoExameRepository = anexoExameRepository;
    }

    // LISTAR USUÁRIOS
    public List<Usuario> listarUsuarios() {
        return usuarioRepository.findAll(
                Sort.by("nome")
        );
    }

    public List<Usuario> filtrarUsuarios(
            String busca,
            String cargo,
            String status) {

        // Normalizar o texto digitado
        String termo = normalizarTexto(busca);

        // Manter apenas os números para pesquisar CPF
        String cpfBusca = busca == null
                ? ""
                : busca.replaceAll("\\D", "");

        String cargoFiltro = cargo == null
                ? ""
                : cargo.trim();

        String statusFiltro = status == null
                ? ""
                : status.trim().toLowerCase(Locale.ROOT);

        return listarUsuarios()
                .stream()

                // FILTRO DE NOME OU CPF
                .filter(usuario -> {

                    boolean nomeEncontrado =
                            normalizarTexto(
                                    usuario.getNome()
                            ).contains(termo);

                    boolean cpfEncontrado =
                            !cpfBusca.isEmpty()
                                    && usuario.getCpf() != null
                                    && usuario.getCpf()
                                    .replaceAll("\\D", "")
                                    .contains(cpfBusca);

                    return termo.isEmpty()
                            || nomeEncontrado
                            || cpfEncontrado;
                })

                // FILTRO DE CARGO
                .filter(usuario ->
                        cargoFiltro.isEmpty()
                                || cargoFiltro.equalsIgnoreCase(
                                usuario.getCargo()
                        )
                )

                // FILTRO DE STATUS
                .filter(usuario -> {

                    if (statusFiltro.equals("ativo")) {
                        return usuario.isAtivo();
                    }

                    if (statusFiltro.equals("inativo")) {
                        return !usuario.isAtivo();
                    }

                    return true;
                })

                .toList();
    }

    // REMOVER ACENTOS E PADRONIZAR TEXTO
    private String normalizarTexto(String texto) {

        if (texto == null) {
            return "";
        }

        String normalizado = Normalizer.normalize(
                texto,
                Normalizer.Form.NFD
        );

        return normalizado
                .replaceAll("\\p{M}", "")
                .toLowerCase(Locale.ROOT)
                .trim();
    }

    // BUSCAR USUÁRIO
    public Usuario buscarUsuario(Long id) {
        return usuarioRepository.findById(id)
                .orElseThrow(() ->
                        new IllegalArgumentException(
                                "Usuário não encontrado."
                        )
                );
    }

    // PREENCHER FORMULÁRIO DE EDIÇÃO
    public AdminUsuarioForm formularioUsuario(Long id) {

        Usuario usuario = buscarUsuario(id);

        AdminUsuarioForm form = new AdminUsuarioForm();

        form.setNome(usuario.getNome());
        form.setCpf(usuario.getCpf());
        form.setEmail(usuario.getEmail());
        form.setCargo(usuario.getCargo());
        form.setEspecialidade(usuario.getEspecialidade());
        form.setAtivo(usuario.isAtivo());

        // Nunca enviar a senha criptografada ao HTML.

        return form;
    }

    // CADASTRAR USUÁRIO
    @Transactional
    public Usuario criarUsuario(AdminUsuarioForm form) {

        Usuario usuario = new Usuario();

        validarEAplicar(form, usuario, true);

        // Não cria vínculo na tabela administradores.

        return usuarioRepository.save(usuario);
    }

    // EDITAR USUÁRIO
    @Transactional
    public Usuario editarUsuario(
            Long id,
            AdminUsuarioForm form,
            String emailLogado) {

        Usuario usuario = buscarUsuario(id);

        verificarPermissao(
                usuario, emailLogado
        );

        validarEAplicar(form, usuario, false);

        return usuarioRepository.save(usuario);
    }

    // EXCLUIR USUÁRIO

    @Transactional
    public void excluirUsuario(
            Long id,
            String emailLogado) {

        Usuario usuario = buscarUsuario(id);

        verificarPermissao(usuario, emailLogado);

        boolean possuiAgendamentos =
                agendamentoRepository
                        .existsByProfissional_Id(id);

        boolean possuiHistorico =
                historicoExameRepository
                        .existsByProfissional_Id(id);

        boolean possuiResultados =
                resultadoExameRepository
                        .existsByProfissional_Id(id);

        boolean possuiAnexos =
                anexoExameRepository
                        .existsByProfissional_Id(id);

        if (possuiAgendamentos ||
                possuiHistorico ||
                possuiResultados ||
                possuiAnexos) {

            throw new IllegalArgumentException(
                    "Este usuário possui registros " +
                            "vinculados ao sistema. " +
                            "Desative a conta em vez de excluí-la."
            );
        }

        usuarioRepository.delete(usuario);
    }


    // VERIFICAR SE PODE EDITAR OU EXCLUIR
    private void verificarPermissao(
            Usuario usuario,
            String emailLogado) {

        if (usuario.getEmail()
                .equalsIgnoreCase(emailLogado)) {

            throw new IllegalArgumentException(
                    "Você não pode editar ou excluir " +
                            "sua própria conta nesta tela."
            );
        }

        if (administradorRepository
                .existsByUsuario_Id(usuario.getId())) {

            throw new IllegalArgumentException(
                    "Não é permitido alterar ou excluir " +
                            "contas administradoras nesta tela."
            );
        }
    }

    // VALIDAR DADOS E ATUALIZAR A ENTIDADE
    private void validarEAplicar(
            AdminUsuarioForm form,
            Usuario usuario,
            boolean criacao) {

        String nome = textoObrigatorio(
                form.getNome(), "nome", 120
        );

        String cpf = textoObrigatorio(
                form.getCpf(), "CPF", 14
        ).replaceAll("\\D", "");

        if (!usuarioService.validarCPF(cpf)) {
            throw new IllegalArgumentException(
                    "Informe um CPF válido."
            );
        }

        String email = textoObrigatorio(
                form.getEmail(), "e-mail", 160
        ).toLowerCase();

        if (!EMAIL.matcher(email).matches()) {
            throw new IllegalArgumentException(
                    "Informe um e-mail válido."
            );
        }

        boolean cpfDuplicado = criacao
                ? usuarioRepository.existsByCpf(cpf)
                : usuarioRepository
                .existsByCpfAndIdNot(
                        cpf, usuario.getId()
                );

        if (cpfDuplicado) {
            throw new IllegalArgumentException(
                    "CPF já cadastrado."
            );
        }

        boolean emailDuplicado = criacao
                ? usuarioRepository.existsByEmail(email)
                : usuarioRepository
                .existsByEmailAndIdNot(
                        email, usuario.getId()
                );

        if (emailDuplicado) {
            throw new IllegalArgumentException(
                    "E-mail já cadastrado."
            );
        }

        String cargo = textoObrigatorio(
                form.getCargo(), "cargo", 60
        );

        if (!CARGOS.contains(cargo)) {
            throw new IllegalArgumentException(
                    "Selecione um cargo válido."
            );
        }

        String especialidade = null;

        if (CARGOS_ATENDIMENTO.contains(cargo)) {

            especialidade = textoObrigatorio(
                    form.getEspecialidade(),
                    "especialidade",
                    100
            );
        }

        String senha = form.getSenha();

        // Senha obrigatória na criação.
        // Opcional na edição.

        if (criacao ||
                (senha != null && !senha.isBlank())) {

            if (senha == null ||
                    senha.length() < 8 ||
                    senha.length() > 72) {

                throw new IllegalArgumentException(
                        "A senha deve ter entre 8 e 72 caracteres."
                );
            }

            if (!senha.equals(
                    form.getConfirmarSenha())) {

                throw new IllegalArgumentException(
                        "As senhas não conferem."
                );
            }

            usuario.setSenha(
                    passwordEncoder.encode(senha)
            );
        }

        usuario.setNome(nome);
        usuario.setCpf(cpf);
        usuario.setEmail(email);
        usuario.setCargo(cargo);
        usuario.setEspecialidade(especialidade);
        usuario.setAtivo(form.isAtivo());
    }

    // VALIDAÇÃO DE CAMPOS OBRIGATÓRIOS
    private String textoObrigatorio(
            String valor,
            String campo,
            int maximo) {

        if (valor == null || valor.isBlank()) {
            throw new IllegalArgumentException(
                    "Informe " + campo + "."
            );
        }

        String texto = valor.trim();

        if (texto.length() > maximo) {
            throw new IllegalArgumentException(
                    "O campo " + campo +
                            " ultrapassa " + maximo + " caracteres."
            );
        }

        return texto;
    }
}
