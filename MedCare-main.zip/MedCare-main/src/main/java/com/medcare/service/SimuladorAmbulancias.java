package com.medcare.service;

import com.medcare.model.StatusSimulacao;
import com.medcare.repository.SimulacaoAmbulanciaRepository;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class SimuladorAmbulancias {

    private static final Logger log =
            LoggerFactory.getLogger(
                    SimuladorAmbulancias.class
            );

    private final SimulacaoAmbulanciaRepository simulacoes;
    private final RastreamentoService rastreamentoService;

    public SimuladorAmbulancias(
            SimulacaoAmbulanciaRepository simulacoes,
            RastreamentoService rastreamentoService) {

        this.simulacoes = simulacoes;
        this.rastreamentoService = rastreamentoService;
    }

    @Scheduled(
            fixedDelayString =
                    "${medcare.ambulancias.intervalo-ms:2000}"
    )
    public void executar() {

        List<Long> ids = simulacoes
                .findByStatus(StatusSimulacao.EM_ANDAMENTO)
                .stream()
                .map(s -> s.getId())
                .toList();

        for (Long id : ids) {

            try {
                rastreamentoService.avancar(id);

            } catch (Exception e) {
                log.warn(
                        "Falha ao avançar simulação {}",
                        id,
                        e
                );
            }
        }
    }
}
