package com.medcare.service;

import com.medcare.model.*;
import com.medcare.repository.*;

import org.springframework.context.ApplicationEventPublisher;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.Instant;
import java.util.List;
import java.util.Optional;

@Service
public class RastreamentoService {

    // Coordenada inicial fictícia em Campinas.
    private static final double LAT_BASE = -22.90556;
    private static final double LON_BASE = -47.06083;

    private final AmbulanciaRepository ambulancias;
    private final SimulacaoAmbulanciaRepository simulacoes;
    private final LocalizacaoAmbulanciaRepository localizacoes;
    private final TrajetosSimulados trajetos;
    private final ApplicationEventPublisher eventos;

    public RastreamentoService(
            AmbulanciaRepository ambulancias,
            SimulacaoAmbulanciaRepository simulacoes,
            LocalizacaoAmbulanciaRepository localizacoes,
            TrajetosSimulados trajetos,
            ApplicationEventPublisher eventos) {

        this.ambulancias = ambulancias;
        this.simulacoes = simulacoes;
        this.localizacoes = localizacoes;
        this.trajetos = trajetos;
        this.eventos = eventos;
    }

    // DADOS RECEBIDOS PELO CONTROLLER

    public record Cadastro(String codigo, String nome) {}

    public record Inicio(TipoTrajeto trajeto) {}

    // DADOS DEVOLVIDOS AO FRONTEND

    public record Resumo(
            Long id,
            String codigo,
            String nome,
            Long simulacaoId,
            String status,
            String trajeto,
            double latitude,
            double longitude,
            int indiceAtual
    ) {}

    public record Posicao(
            int indice,
            double latitude,
            double longitude,
            Instant registradaEm
    ) {}

    // Evento para transmissão após salvar no banco.
    public record Atualizacao(Resumo resumo) {}

    // LISTAR TODAS AS AMBULÂNCIAS

    @Transactional(readOnly = true)
    public List<Resumo> listar() {

        return ambulancias.findAll(
                Sort.by("codigo")
        ).stream().map(this::obterResumo).toList();
    }

    private Resumo obterResumo(Ambulancia ambulancia) {

        Optional<SimulacaoAmbulancia> ultima =
                simulacoes.findFirstByAmbulanciaIdOrderByIdDesc(
                        ambulancia.getId()
                );

        if (ultima.isEmpty()) {
            return resumo(ambulancia, null, null);
        }

        SimulacaoAmbulancia simulacao = ultima.get();

        LocalizacaoAmbulancia posicao = localizacoes
                .findFirstBySimulacaoIdOrderByIndiceDesc(
                        simulacao.getId()
                )
                .orElse(null);

        return resumo(ambulancia, simulacao, posicao);
    }

    private Resumo resumo(
            Ambulancia ambulancia,
            SimulacaoAmbulancia simulacao,
            LocalizacaoAmbulancia posicao) {

        return new Resumo(
                ambulancia.getId(),
                ambulancia.getCodigo(),
                ambulancia.getNome(),
                simulacao == null ? null : simulacao.getId(),
                simulacao == null
                        ? "DISPONIVEL"
                        : simulacao.getStatus().name(),
                simulacao == null
                        ? null
                        : simulacao.getTrajeto().name(),
                posicao == null
                        ? LAT_BASE
                        : posicao.getLatitude(),
                posicao == null
                        ? LON_BASE
                        : posicao.getLongitude(),
                posicao == null ? 0 : posicao.getIndice()
        );
    }

    private void notificar(Resumo resumo) {
        eventos.publishEvent(new Atualizacao(resumo));
    }

    // CADASTRAR AMBULÂNCIA

    @Transactional
    public Resumo cadastrar(Cadastro cadastro) {

        if (cadastro == null ||
                cadastro.codigo() == null ||
                cadastro.nome() == null) {

            throw new IllegalArgumentException(
                    "Informe código e nome da ambulância."
            );
        }

        String codigo = cadastro.codigo().trim()
                .toUpperCase();

        String nome = cadastro.nome().trim();

        if (!codigo.matches("[A-Z0-9-]{2,30}") ||
                nome.isBlank() ||
                nome.length() > 100) {

            throw new IllegalArgumentException(
                    "Código ou nome inválido."
            );
        }

        if (ambulancias.existsByCodigoIgnoreCase(codigo)) {
            throw new IllegalArgumentException(
                    "Já existe uma ambulância com esse código."
            );
        }

        Ambulancia ambulancia = new Ambulancia();
        ambulancia.setCodigo(codigo);
        ambulancia.setNome(nome);
        ambulancia.setAtiva(true);

        ambulancias.saveAndFlush(ambulancia);

        Resumo resposta = resumo(ambulancia, null, null);
        notificar(resposta);

        return resposta;
    }

    // INICIAR SIMULAÇÃO

    @Transactional
    public Resumo iniciar(Long ambulanciaId, TipoTrajeto trajeto) {

        if (trajeto == null) {
            throw new IllegalArgumentException(
                    "Escolha um trajeto."
            );
        }

        Ambulancia ambulancia = ambulancias
                .bloquearPorId(ambulanciaId)
                .orElseThrow(() ->
                        new IllegalArgumentException(
                                "Ambulância não encontrada."
                        )
                );

        if (!ambulancia.isAtiva()) {
            throw new IllegalArgumentException(
                    "Ambulância inativa."
            );
        }

        boolean ocupada =
                simulacoes.existsByAmbulanciaIdAndStatusIn(
                        ambulanciaId,
                        List.of(
                                StatusSimulacao.EM_ANDAMENTO,
                                StatusSimulacao.PAUSADA
                        )
                );

        if (ocupada) {
            throw new IllegalArgumentException(
                    "Esta ambulância já possui uma simulação ativa."
            );
        }

        SimulacaoAmbulancia simulacao =
                new SimulacaoAmbulancia();

        simulacao.setAmbulancia(ambulancia);
        simulacao.setTrajeto(trajeto);
        simulacao.setStatus(StatusSimulacao.EM_ANDAMENTO);
        simulacao.setIndiceAtual(0);
        simulacao.setIniciadaEm(Instant.now());

        simulacoes.saveAndFlush(simulacao);

        TrajetosSimulados.Ponto origem =
                trajetos.pontos(trajeto).get(0);

        LocalizacaoAmbulancia posicao =
                salvarLocalizacao(simulacao, 0, origem);

        Resumo resposta =
                resumo(ambulancia, simulacao, posicao);

        notificar(resposta);
        return resposta;
    }

    // LOCALIZAR SIMULAÇÃO COM BLOQUEIO

    private SimulacaoAmbulancia bloquearSimulacao(Long id) {
        return simulacoes.bloquearPorId(id)
                .orElseThrow(() ->
                        new IllegalArgumentException(
                                "Simulação não encontrada."
                        )
                );
    }

    // BUSCAR ÚLTIMA POSIÇÃO

    private LocalizacaoAmbulancia ultimaPosicao(Long id) {

        return localizacoes
                .findFirstBySimulacaoIdOrderByIndiceDesc(id)
                .orElseThrow(() ->
                        new IllegalStateException(
                                "Simulação sem posição inicial."
                        )
                );
    }

    // PAUSAR

    @Transactional
    public Resumo pausar(Long simulacaoId) {

        SimulacaoAmbulancia simulacao =
                bloquearSimulacao(simulacaoId);

        if (simulacao.getStatus()
                != StatusSimulacao.EM_ANDAMENTO) {

            throw new IllegalArgumentException(
                    "Somente simulações em andamento podem ser pausadas."
            );
        }

        simulacao.setStatus(StatusSimulacao.PAUSADA);

        Resumo resposta = resumo(
                simulacao.getAmbulancia(),
                simulacao,
                ultimaPosicao(simulacaoId)
        );

        notificar(resposta);
        return resposta;
    }

    // RETOMAR

    @Transactional
    public Resumo retomar(Long simulacaoId) {

        SimulacaoAmbulancia simulacao =
                bloquearSimulacao(simulacaoId);

        if (simulacao.getStatus()
                != StatusSimulacao.PAUSADA) {

            throw new IllegalArgumentException(
                    "Esta simulação não está pausada."
            );
        }

        simulacao.setStatus(StatusSimulacao.EM_ANDAMENTO);

        Resumo resposta = resumo(
                simulacao.getAmbulancia(),
                simulacao,
                ultimaPosicao(simulacaoId)
        );

        notificar(resposta);
        return resposta;
    }

    // FINALIZAR MANUALMENTE

    @Transactional
    public Resumo finalizar(Long simulacaoId) {

        SimulacaoAmbulancia simulacao =
                bloquearSimulacao(simulacaoId);

        if (simulacao.getStatus()
                == StatusSimulacao.FINALIZADA) {

            throw new IllegalArgumentException(
                    "Esta simulação já foi finalizada."
            );
        }

        simulacao.setStatus(StatusSimulacao.FINALIZADA);
        simulacao.setFinalizadaEm(Instant.now());

        Resumo resposta = resumo(
                simulacao.getAmbulancia(),
                simulacao,
                ultimaPosicao(simulacaoId)
        );

        notificar(resposta);
        return resposta;
    }

    // SALVAR UMA NOVA COORDENADA

    private LocalizacaoAmbulancia salvarLocalizacao(
            SimulacaoAmbulancia simulacao,
            int indice,
            TrajetosSimulados.Ponto ponto) {

        LocalizacaoAmbulancia localizacao =
                new LocalizacaoAmbulancia();

        localizacao.setSimulacao(simulacao);
        localizacao.setIndice(indice);
        localizacao.setLatitude(ponto.latitude());
        localizacao.setLongitude(ponto.longitude());
        localizacao.setRegistradaEm(Instant.now());

        return localizacoes.saveAndFlush(localizacao);
    }

    // MOVIMENTAÇÃO AUTOMÁTICA

    @Transactional
    public void avancar(Long simulacaoId) {

        SimulacaoAmbulancia simulacao =
                bloquearSimulacao(simulacaoId);

        if (simulacao.getStatus()
                != StatusSimulacao.EM_ANDAMENTO) {
            return;
        }

        List<TrajetosSimulados.Ponto> pontos =
                trajetos.pontos(simulacao.getTrajeto());

        int proximo = simulacao.getIndiceAtual() + 1;

        if (proximo >= pontos.size()) {
            simulacao.setStatus(StatusSimulacao.FINALIZADA);
            simulacao.setFinalizadaEm(Instant.now());

            notificar(resumo(
                    simulacao.getAmbulancia(),
                    simulacao,
                    ultimaPosicao(simulacaoId)
            ));
            return;
        }

        simulacao.setIndiceAtual(proximo);

        LocalizacaoAmbulancia posicao = salvarLocalizacao(
                simulacao,
                proximo,
                pontos.get(proximo)
        );

        // Finalizar ao chegar ao destino.
        if (proximo == pontos.size() - 1) {
            simulacao.setStatus(StatusSimulacao.FINALIZADA);
            simulacao.setFinalizadaEm(Instant.now());
        }

        notificar(resumo(
                simulacao.getAmbulancia(),
                simulacao,
                posicao
        ));
    }

    // HISTÓRICO DA ÚLTIMA SIMULAÇÃO

    @Transactional(readOnly = true)
    public List<Posicao> historico(Long ambulanciaId) {

        if (!ambulancias.existsById(ambulanciaId)) {
            throw new IllegalArgumentException(
                    "Ambulância não encontrada."
            );
        }

        Optional<SimulacaoAmbulancia> ultima =
                simulacoes.findFirstByAmbulanciaIdOrderByIdDesc(
                        ambulanciaId
                );

        if (ultima.isEmpty()) {
            return List.of();
        }

        return localizacoes
                .findBySimulacaoIdOrderByIndiceAsc(
                        ultima.get().getId()
                )
                .stream()
                .map(localizacao -> new Posicao(
                        localizacao.getIndice(),
                        localizacao.getLatitude(),
                        localizacao.getLongitude(),
                        localizacao.getRegistradaEm()
                ))
                .toList();
    }

    // ROTA COMPLETA PARA EXIBIÇÃO NO MAPA

    public List<TrajetosSimulados.Ponto> rota(
            TipoTrajeto tipo) {
        return trajetos.pontos(tipo);
    }
}
