
package com.medcare.service;

import com.medcare.model.Usuario;
import com.medcare.repository.UsuarioRepository;
import com.medcare.repository.AdministradorRepository;

import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

@Service
public class UsuarioDetailsService
        implements UserDetailsService {

    private final UsuarioRepository usuarioRepository;
    private final AdministradorRepository administradorRepository;

    public UsuarioDetailsService(
            UsuarioRepository usuarioRepository,
            AdministradorRepository administradorRepository) {

        this.usuarioRepository = usuarioRepository;
        this.administradorRepository = administradorRepository;
    }

    @Override
    public UserDetails loadUserByUsername(String email)
            throws UsernameNotFoundException {

        Usuario usuario = usuarioRepository.findByEmail(email)
                .orElseThrow(() ->
                        new UsernameNotFoundException(
                                "Usuário não encontrado."
                        )
                );

        boolean ehAdministrador =
                administradorRepository
                        .existsByUsuario_Id(usuario.getId());

        String[] permissoes = ehAdministrador
                ? new String[]{"ROLE_USER", "ROLE_ADMIN"}
                : new String[]{"ROLE_USER"};

        return User.builder()
                .username(usuario.getEmail())
                .password(usuario.getSenha())
                .authorities(permissoes)
                .disabled(!usuario.isAtivo())
                .build();
    }
}
