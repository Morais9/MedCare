package com.medcare.service;

import com.medcare.model.TipoTrajeto;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class TrajetosSimulados {

    public record Ponto(double latitude, double longitude) {}

    public List<Ponto> pontos(TipoTrajeto trajeto) {

        List<Ponto> referencias;

        switch (trajeto) {

            case CENTRO_CAMBUI -> referencias = List.of(
                    new Ponto(-22.90556, -47.06083),
                    new Ponto(-22.90074, -47.06468),
                    new Ponto(-22.89469, -47.05848),
                    new Ponto(-22.89179, -47.05534)
            );

            case CENTRO_TAQUARAL -> referencias = List.of(
                    new Ponto(-22.90556, -47.06083),
                    new Ponto(-22.89740, -47.05400),
                    new Ponto(-22.88920, -47.04600),
                    new Ponto(-22.87590, -47.04800)
            );

            default -> throw new IllegalArgumentException(
                    "Trajeto inválido."
            );
        }

        return interpolar(referencias);
    }

    private List<Ponto> interpolar(List<Ponto> referencias) {

        List<Ponto> resultado = new ArrayList<>();

        // Dez deslocamentos entre cada par de pontos.
        int subdivisoes = 10;

        for (int i = 0; i < referencias.size() - 1; i++) {

            Ponto origem = referencias.get(i);
            Ponto destino = referencias.get(i + 1);

            for (int passo = 0; passo < subdivisoes; passo++) {

                double proporcao =
                        (double) passo / subdivisoes;

                double latitude = origem.latitude()
                        + (destino.latitude() - origem.latitude())
                        * proporcao;

                double longitude = origem.longitude()
                        + (destino.longitude() - origem.longitude())
                        * proporcao;

                resultado.add(
                        new Ponto(latitude, longitude)
                );
            }
        }

        resultado.add(
                referencias.get(referencias.size() - 1)
        );

        return resultado;
    }
}
