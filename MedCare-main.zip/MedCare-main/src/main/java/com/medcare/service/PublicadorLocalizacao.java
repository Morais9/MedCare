package com.medcare.service;

import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.stereotype.Component;
import org.springframework.transaction.event.TransactionalEventListener;
import org.springframework.transaction.event.TransactionPhase;

@Component
public class PublicadorLocalizacao {

    private final SimpMessagingTemplate mensagens;

    public PublicadorLocalizacao(
            SimpMessagingTemplate mensagens) {
        this.mensagens = mensagens;
    }

    @TransactionalEventListener(
            phase = TransactionPhase.AFTER_COMMIT
    )
    public void publicar(
            RastreamentoService.Atualizacao evento) {

        mensagens.convertAndSend(
                "/topic/admin/ambulancias",
                evento.resumo()
        );
    }
}
