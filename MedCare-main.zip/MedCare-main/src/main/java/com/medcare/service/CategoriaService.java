package com.medcare.service;

import com.medcare.dto.CategoriaForm;
import com.medcare.model.Categoria;
import com.medcare.repository.CategoriaRepository;

import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.text.Normalizer;
import java.util.Locale;
import java.util.List;

@Service
@Transactional(readOnly = true)
public class CategoriaService {

    private final CategoriaRepository categoriaRepository;

    public CategoriaService(
            CategoriaRepository categoriaRepository) {
        this.categoriaRepository = categoriaRepository;
    }

    // LISTAR
    public List<Categoria> listar() {
        return categoriaRepository.findAll(
                Sort.by("nome")
        );
    }

    public List<Categoria> pesquisarPorNome(String busca) {

        // Se a pesquisa estiver vazia, retorna todas.
        if (busca == null || busca.isBlank()) {
            return listar();
        }

        String termo = normalizarTexto(busca);

        return listar()
                .stream()
                .filter(categoria ->
                        normalizarTexto(categoria.getNome())
                                .contains(termo)
                )
                .toList();
    }

    // Remove acentos e ignora letras maiúsculas.
    private String normalizarTexto(String texto) {

        if (texto == null) {
            return "";
        }

        String normalizado = Normalizer.normalize(
                texto,
                Normalizer.Form.NFD
        );

        return normalizado
                .replaceAll("\\p{M}", "")
                .toLowerCase(Locale.ROOT)
                .trim();
    }


    // BUSCAR POR ID
    public Categoria buscar(Long id) {
        return categoriaRepository.findById(id)
                .orElseThrow(() ->
                        new IllegalArgumentException(
                                "Categoria não encontrada."
                        )
                );
    }

    // PREENCHER FORMULÁRIO DE EDIÇÃO
    public CategoriaForm formulario(Long id) {
        Categoria categoria = buscar(id);

        CategoriaForm form = new CategoriaForm();

        form.setNome(categoria.getNome());
        form.setDescricao(categoria.getDescricao());
        form.setAtivo(categoria.isAtivo());

        return form;
    }

    // CADASTRAR
    @Transactional
    public Categoria criar(CategoriaForm form) {
        Categoria categoria = new Categoria();

        validar(form, categoria, true);

        return categoriaRepository.save(categoria);
    }

    // EDITAR
    @Transactional
    public Categoria editar(
            Long id,
            CategoriaForm form) {

        Categoria categoria = buscar(id);

        validar(form, categoria, false);

        return categoriaRepository.save(categoria);
    }

    // EXCLUIR
    @Transactional
    public void excluir(Long id) {
        Categoria categoria = buscar(id);

        categoriaRepository.delete(categoria);
    }

    // VALIDAR
    private void validar(
            CategoriaForm form,
            Categoria categoria,
            boolean criacao) {

        if (form.getNome() == null ||
                form.getNome().isBlank()) {

            throw new IllegalArgumentException(
                    "Informe o nome da categoria."
            );
        }

        String nome = form.getNome().trim();

        if (nome.length() > 100) {
            throw new IllegalArgumentException(
                    "Nome muito longo."
            );
        }

        boolean duplicado = criacao
                ? categoriaRepository
                .existsByNomeIgnoreCase(nome)
                : categoriaRepository
                .existsByNomeIgnoreCaseAndIdNot(
                        nome, categoria.getId()
                );

        if (duplicado) {
            throw new IllegalArgumentException(
                    "Já existe uma categoria com esse nome."
            );
        }

        String descricao = form.getDescricao() == null
                ? ""
                : form.getDescricao().trim();

        if (descricao.length() > 255) {
            throw new IllegalArgumentException(
                    "Descrição muito longa."
            );
        }

        categoria.setNome(nome);
        categoria.setDescricao(descricao);
        categoria.setAtivo(form.isAtivo());
    }
}
