package com.medcare.controller;

import com.medcare.dto.AdminUsuarioForm;
import com.medcare.dto.CategoriaForm;
import com.medcare.model.Categoria;
import com.medcare.model.Usuario;

import com.medcare.repository.UsuarioRepository;
import com.medcare.repository.AdministradorRepository;

import com.medcare.service.AdministracaoService;
import com.medcare.service.CategoriaService;

import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.List;

@Controller
@RequestMapping("/administracao")
public class AdministracaoController {

    private final AdministracaoService administracaoService;
    private final CategoriaService categoriaService;
    private final UsuarioRepository usuarioRepository;
    private final AdministradorRepository administradorRepository;

    public AdministracaoController(
            AdministracaoService administracaoService,
            CategoriaService categoriaService,
            UsuarioRepository usuarioRepository,
            AdministradorRepository administradorRepository) {

        this.administracaoService = administracaoService;
        this.categoriaService = categoriaService;
        this.usuarioRepository = usuarioRepository;
        this.administradorRepository = administradorRepository;
    }



    @GetMapping
    public String listar(

            // PESQUISA DE USUÁRIOS
            @RequestParam(
                    name = "busca",
                    defaultValue = ""
            ) String busca,

            // FILTRO DE CARGO
            @RequestParam(
                    name = "cargo",
                    defaultValue = ""
            ) String cargo,

            // FILTRO DE STATUS
            @RequestParam(
                    name = "status",
                    defaultValue = ""
            ) String status,

            // PESQUISA DE CATEGORIAS
            @RequestParam(
                    name = "buscaCategoria",
                    defaultValue = ""
            ) String buscaCategoria,

            Model model,
            Authentication authentication) {

        // Carregar os dados normais da página
        String pagina = montarPagina(
                model,
                authentication,
                null,
                null
        );

        // PESQUISA E FILTROS DOS USUÁRIOS
        List<Usuario> usuariosFiltrados =
                administracaoService.filtrarUsuarios(
                        busca,
                        cargo,
                        status
                );

        model.addAttribute(
                "usuarios",
                usuariosFiltrados
        );

        model.addAttribute("busca", busca);
        model.addAttribute("cargoSelecionado", cargo);
        model.addAttribute("statusSelecionado", status);

        model.addAttribute(
                "totalFiltrado",
                usuariosFiltrados.size()
        );

        model.addAttribute(
                "totalUsuarios",
                administracaoService.listarUsuarios().size()
        );

        // PESQUISA DAS CATEGORIAS
        List<Categoria> categoriasFiltradas =
                categoriaService.pesquisarPorNome(
                        buscaCategoria
                );

        model.addAttribute(
                "categorias",
                categoriasFiltradas
        );

        model.addAttribute(
                "buscaCategoria",
                buscaCategoria
        );

        model.addAttribute(
                "totalCategoriasFiltradas",
                categoriasFiltradas.size()
        );

        model.addAttribute(
                "totalCategorias",
                categoriaService.listar().size()
        );

        return pagina;
    }

    // ABRIR EDIÇÃO DE USUÁRIO
    @GetMapping("/usuarios/{id}/editar")
    public String formularioEdicaoUsuario(
            @PathVariable Long id,
            Model model,
            Authentication authentication,
            RedirectAttributes aviso) {

        try {
            return montarPagina(
                    model, authentication, id, null
            );

        } catch (IllegalArgumentException e) {

            aviso.addFlashAttribute(
                    "erro", e.getMessage()
            );

            return "redirect:/administracao";
        }
    }

    // ABRIR EDIÇÃO DE CATEGORIA
    @GetMapping("/categorias/{id}/editar")
    public String formularioEdicaoCategoria(
            @PathVariable Long id,
            Model model,
            Authentication authentication,
            RedirectAttributes aviso) {

        try {
            return montarPagina(
                    model, authentication, null, id
            );

        } catch (IllegalArgumentException e) {

            aviso.addFlashAttribute(
                    "erro", e.getMessage()
            );

            return "redirect:/administracao";
        }
    }

    // PREPARAR DADOS DA PÁGINA
    private String montarPagina(
            Model model,
            Authentication authentication,
            Long usuarioId,
            Long categoriaId) {

        Usuario logado = usuarioRepository
                .findByEmail(authentication.getName())
                .orElseThrow(() ->
                        new IllegalStateException(
                                "Usuário autenticado não encontrado."
                        )
                );

        model.addAttribute(
                "nomeUsuario", logado.getNome()
        );


        model.addAttribute("usuarioLogado", logado);

        model.addAttribute("cargoUsuario", logado.getCargo());


        String nome = logado.getNome() == null
                ? ""
                : logado.getNome().trim();

        String iniciais = "U";

        if (!nome.isEmpty()) {
            String[] partes = nome.split("\\s+");

            iniciais = partes[0].substring(0, 1);

            if (partes.length > 1) {
                iniciais += partes[partes.length - 1]
                        .substring(0, 1);
            }
        }

        model.addAttribute(
                "iniciaisUsuario",
                iniciais.toUpperCase()
        );

        model.addAttribute(
                "usuarios",
                administracaoService.listarUsuarios()
        );

        model.addAttribute(
                "categorias",
                categoriaService.listar()
        );

        model.addAttribute(
                "idsAdministradores",
                administradorRepository
                        .listarIdsDeAdministradores()
        );

        model.addAttribute(
                "usuarioForm",
                usuarioId == null
                        ? new AdminUsuarioForm()
                        : administracaoService.formularioUsuario(usuarioId)
        );

        model.addAttribute(
                "categoriaForm",
                categoriaId == null
                        ? new CategoriaForm()
                        : categoriaService.formulario(categoriaId)
        );

        model.addAttribute(
                "editandoUsuarioId", usuarioId
        );

        model.addAttribute(
                "editandoCategoriaId", categoriaId
        );

        return "administracao";
    }

    // CRIAR USUÁRIO
    @PostMapping("/usuarios")
    public String criarUsuario(
            @ModelAttribute AdminUsuarioForm form,
            RedirectAttributes aviso) {

        try {
            administracaoService.criarUsuario(form);

            aviso.addFlashAttribute(
                    "sucesso", "Usuário criado com sucesso."
            );

        } catch (IllegalArgumentException e) {

            aviso.addFlashAttribute(
                    "erro", e.getMessage()
            );
        }

        return "redirect:/administracao#usuarios";
    }

    // EDITAR USUÁRIO
    @PostMapping("/usuarios/{id}")
    public String editarUsuario(
            @PathVariable Long id,
            @ModelAttribute AdminUsuarioForm form,
            Authentication authentication,
            RedirectAttributes aviso) {

        try {
            administracaoService.editarUsuario(
                    id,
                    form,
                    authentication.getName()
            );

            aviso.addFlashAttribute(
                    "sucesso", "Usuário atualizado com sucesso."
            );

        } catch (IllegalArgumentException e) {

            aviso.addFlashAttribute(
                    "erro", e.getMessage()
            );
        }

        return "redirect:/administracao#usuarios";
    }

    // EXCLUIR USUÁRIO
    @PostMapping("/usuarios/{id}/excluir")
    public String excluirUsuario(
            @PathVariable Long id,
            Authentication authentication,
            RedirectAttributes aviso) {

        try {
            administracaoService.excluirUsuario(
                    id,
                    authentication.getName()
            );

            aviso.addFlashAttribute(
                    "sucesso", "Usuário excluído com sucesso."
            );

        } catch (IllegalArgumentException e) {

            aviso.addFlashAttribute(
                    "erro", e.getMessage()
            );
        }

        return "redirect:/administracao#usuarios";
    }

    // CRIAR CATEGORIA
    @PostMapping("/categorias")
    public String criarCategoria(
            @ModelAttribute CategoriaForm form,
            RedirectAttributes aviso) {

        try {
            categoriaService.criar(form);

            aviso.addFlashAttribute(
                    "sucesso", "Categoria criada com sucesso."
            );

        } catch (IllegalArgumentException e) {

            aviso.addFlashAttribute(
                    "erro", e.getMessage()
            );
        }

        return "redirect:/administracao#categorias";
    }

    // EDITAR CATEGORIA
    @PostMapping("/categorias/{id}")
    public String editarCategoria(
            @PathVariable Long id,
            @ModelAttribute CategoriaForm form,
            RedirectAttributes aviso) {

        try {
            categoriaService.editar(id, form);

            aviso.addFlashAttribute(
                    "sucesso", "Categoria atualizada com sucesso."
            );

        } catch (IllegalArgumentException e) {

            aviso.addFlashAttribute(
                    "erro", e.getMessage()
            );
        }

        return "redirect:/administracao#categorias";
    }

    // EXCLUIR CATEGORIA
    @PostMapping("/categorias/{id}/excluir")
    public String excluirCategoria(
            @PathVariable Long id,
            RedirectAttributes aviso) {

        try {
            categoriaService.excluir(id);

            aviso.addFlashAttribute(
                    "sucesso", "Categoria excluída com sucesso."
            );

        } catch (IllegalArgumentException e) {

            aviso.addFlashAttribute(
                    "erro", e.getMessage()
            );
        }

        return "redirect:/administracao#categorias";
    }
}
