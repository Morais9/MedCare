package com.medcare.controller;

import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ModelAttribute;

@ControllerAdvice
public class AdministradorMenuAdvice {

    @ModelAttribute("ehAdministrador")
    public boolean ehAdministrador(
            Authentication authentication) {

        if (authentication == null ||
                !authentication.isAuthenticated()) {
            return false;
        }

        return authentication.getAuthorities()
                .stream()
                .anyMatch(autoridade ->
                        autoridade.getAuthority()
                                .equals("ROLE_ADMIN")
                );
    }
}
