package com.medcare.controller;

import com.medcare.model.TipoTrajeto;
import com.medcare.service.RastreamentoService;
import com.medcare.service.TrajetosSimulados;

import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/admin/ambulancias")
public class AmbulanciaRestController {

    private final RastreamentoService rastreamento;

    public AmbulanciaRestController(
            RastreamentoService rastreamento) {
        this.rastreamento = rastreamento;
    }

    // LISTAR AMBULÂNCIAS

    @GetMapping
    public List<RastreamentoService.Resumo> listar() {
        return rastreamento.listar();
    }

    // CADASTRAR AMBULÂNCIA

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public RastreamentoService.Resumo cadastrar(
            @RequestBody RastreamentoService.Cadastro dados) {

        return rastreamento.cadastrar(dados);
    }

    // INICIAR TRAJETO

    @PostMapping("/{id}/iniciar")
    public RastreamentoService.Resumo iniciar(
            @PathVariable Long id,
            @RequestBody RastreamentoService.Inicio dados) {

        if (dados == null) {
            throw new IllegalArgumentException(
                    "Informe o trajeto."
            );
        }

        return rastreamento.iniciar(
                id,
                dados.trajeto()
        );
    }

    // PAUSAR

    @PostMapping("/simulacoes/{id}/pausar")
    public RastreamentoService.Resumo pausar(
            @PathVariable Long id) {

        return rastreamento.pausar(id);
    }

    // RETOMAR

    @PostMapping("/simulacoes/{id}/retomar")
    public RastreamentoService.Resumo retomar(
            @PathVariable Long id) {

        return rastreamento.retomar(id);
    }

    // FINALIZAR

    @PostMapping("/simulacoes/{id}/finalizar")
    public RastreamentoService.Resumo finalizar(
            @PathVariable Long id) {

        return rastreamento.finalizar(id);
    }

    // HISTÓRICO DA ÚLTIMA SIMULAÇÃO

    @GetMapping("/{id}/historico")
    public List<RastreamentoService.Posicao> historico(
            @PathVariable Long id) {

        return rastreamento.historico(id);
    }

    // CONSULTAR TRAJETO COMPLETO

    @GetMapping("/rotas/{tipo}")
    public List<TrajetosSimulados.Ponto> rota(
            @PathVariable TipoTrajeto tipo) {

        return rastreamento.rota(tipo);
    }

    // ERROS DE VALIDAÇÃO

    @ExceptionHandler(IllegalArgumentException.class)
    public ResponseEntity<Map<String, String>> erroValidacao(
            IllegalArgumentException erro) {

        return ResponseEntity.badRequest().body(
                Map.of("erro", erro.getMessage())
        );
    }

    // ERROS DE INTEGRIDADE DO BANCO

    @ExceptionHandler(DataIntegrityViolationException.class)
    public ResponseEntity<Map<String, String>> erroBanco(
            DataIntegrityViolationException erro) {

        return ResponseEntity
                .status(HttpStatus.CONFLICT)
                .body(Map.of(
                        "erro",
                        "Registro duplicado ou operação inválida."
                ));
    }
}
